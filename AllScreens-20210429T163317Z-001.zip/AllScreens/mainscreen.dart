import 'package:drivers_app/Models/Garage.dart';
import 'package:drivers_app/configMaps.dart';
import 'package:drivers_app/tabsPages/earningsTabPage.dart';
import 'package:drivers_app/tabsPages/homeTabPage.dart';
import 'package:drivers_app/tabsPages/profileTabPage.dart';
import 'package:drivers_app/tabsPages/ratingTabPage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

import '../main.dart';

class MainScreen extends StatefulWidget {
  static const String idScreen = "mainScreen";

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen>
    with SingleTickerProviderStateMixin {
  TabController tabController;
  int selectedIndex = 0;

  void onItemClicked(int index) {
    setState(() {
      selectedIndex = index;
      tabController.index = selectedIndex;
    });
  }

  void getCurrentGarage() async {
    var result;
    result =
        await garageRef.child(FirebaseAuth.instance.currentUser.uid).once();
    if (result.value != null) {
      garageInformation = Garage(
          id: FirebaseAuth.instance.currentUser.uid,
          email: result.value["email"],
          nameOfGarage: result.value["nameOfGarage"],
          phone: result.value["phone"],
          status: result.value["status"],
          longtitude: result.value["location"]["longtitude"].toString(),
          latitude: result.value["location"]["latitude"].toString());
      setState(() {
        selectedIndex = 0;
        tabController.index = selectedIndex;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    getCurrentGarage();
    tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    tabController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: TabBarView(
        physics: NeverScrollableScrollPhysics(),
        controller: tabController,
        children: [
          HomeTabPage(),
          EarningsTabPage(),
          RatingTabPage(),
          ProfileTabPage(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Trang Chủ",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.credit_card),
            label: "Ví",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.star),
            label: "Đánh Giá",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Tài Khoản",
          ),
        ],
        unselectedItemColor: Colors.grey,
        selectedItemColor: Colors.blueAccent,
        type: BottomNavigationBarType.fixed,
        selectedLabelStyle: TextStyle(fontSize: 12.0),
        showUnselectedLabels: true,
        currentIndex: selectedIndex,
        onTap: onItemClicked,
      ),
    );
  }
}
