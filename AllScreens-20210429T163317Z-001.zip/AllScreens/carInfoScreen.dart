import 'package:drivers_app/AllScreens/mainscreen.dart';
import 'package:drivers_app/AllScreens/registerationScreen.dart';
import 'package:drivers_app/configMaps.dart';
import 'package:drivers_app/main.dart';
import 'package:flutter/material.dart';


class CarInfoScreen extends StatefulWidget
{
  static const String idScreen = "carinfo";

  @override
  _CarInfoScreenState createState() => _CarInfoScreenState();
}

class _CarInfoScreenState extends State<CarInfoScreen> {
  TextEditingController garageModelTextEditingController = TextEditingController();

  TextEditingController bankNumberTextEditingController = TextEditingController();


  List<String> garageTypesList = ['Lốp', 'Gầm', 'Điện'];

  String selectedGarageType;

  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 22.0,),
              Image.asset("images/ic_logo.png", width: 390.0, height: 250.0,),
              Padding(
                padding: EdgeInsets.fromLTRB(22.0, 22.0, 22.0, 32.0),
                child: Column(
                  children: [
                    SizedBox(height: 12.0,),
                    Text("Thông Tin Garage", style: TextStyle(fontFamily: "Brand Bold", fontSize: 24.0),),

                    SizedBox(height: 26.0,),
                    TextField(
                      controller: garageModelTextEditingController,
                      decoration: InputDecoration(
                        labelText: "Dịch Vụ Sửa Chữa",
                        hintStyle: TextStyle(color: Colors.grey, fontSize: 10.0),

                      ),
                      style: TextStyle(fontSize: 15.0),
                    ),

                    SizedBox(height: 10.0,),
                    TextField(
                      controller: bankNumberTextEditingController,
                      decoration: InputDecoration(
                        labelText: "Tài khoản ngân hàng",
                        hintStyle: TextStyle(color: Colors.grey, fontSize: 10.0),

                      ),
                      style: TextStyle(fontSize: 15.0),
                    ),

                    SizedBox(height: 26.0,),

                    DropdownButton(
                      iconSize: 40,
                      hint: Text('Xin mời chọn dịch vụ sửa chưa'),
                      value: selectedGarageType,
                      onChanged: (newValue) {
                        setState(() {
                          selectedGarageType = newValue;
                          displayToastMessage(selectedGarageType, context);
                        });
                      },
                      items: garageTypesList.map((car) {
                        return DropdownMenuItem(
                          child: new Text(car),
                          value: car,
                        );
                      }).toList(),
                    ),

                    SizedBox(height: 42.0,),

                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16.0),
                      // ignore: deprecated_member_use
                      child: RaisedButton(
                        onPressed: ()
                        {
                          if(garageModelTextEditingController.text.isEmpty)
                          {
                            displayToastMessage("please write Car Model.", context);
                          }
                          else if(bankNumberTextEditingController.text.isEmpty)
                          {
                            displayToastMessage("please write Car Number.", context);
                          }
                          else if(selectedGarageType == null)
                          {
                            displayToastMessage("please choose Car Type.", context);
                          }
                          else
                          {
                            saveDriverCarInfo(context);
                          }
                        },
                        color: Colors.black54,
                        child: Padding(
                          padding: EdgeInsets.all(17.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("NEXT", style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold, color: Colors.white),),
                              Icon(Icons.arrow_forward, color: Colors.white, size: 26.0,),
                            ],
                          ),
                        ),
                      ),
                    ),

                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void saveDriverCarInfo(context)
  {
    String userId = currentfirebaseUser.uid;

    Map carInfoMap =
    {
      "bank_number": bankNumberTextEditingController.text,
      "garage_model": garageModelTextEditingController.text,
      "type": selectedGarageType,
    };

    driversRef.child(userId).child("Thông Tin Về Garage").set(carInfoMap);

    Navigator.pushNamedAndRemoveUntil(context, MainScreen.idScreen, (route) => false);
  }
}
